# INF632 Homework 2 - Stats Functions (from scratch)
# Name: Hari Krishna Koneti

## Functions (from scratch)
### Harmonic Mean, Sample Std Dev, Pooled Std Dev, T-test, ANOVA, Repeated-Measures ANOVA

## Data loading helpers
ActiGraph raw files contain metadata rows. Fitbit minuteSteps export is wide per hour (measure00..measure59).
